function [ output_args ] = plot_bayes( gp_model )
%PLOT_BAYES Summary of this function goes here
%   Detailed explanation goes here


end


/*
 * Stimulator.cpp
 *
 *  Created on: Dec 3, 2015
 *      Author: mconnolly
 */

#include "Stimulator.h"

namespace std {

Stimulator::Stimulator() {
	// TODO Auto-generated constructor stub

}

Stimulator::~Stimulator() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */

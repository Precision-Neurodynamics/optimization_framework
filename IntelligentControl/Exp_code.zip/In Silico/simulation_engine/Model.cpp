/*
 * Model.cpp
 *
 *  Created on: Aug 23, 2015
 *      Author: mconnolly
 */

#include "Model.h"
#include "mex.h"
Model::Model() {

}

Model::~Model() {
	// TODO Auto-generated destructor stub
}

//void Model::update_noise(){
//
//	for(int c1 = 0; c1 < this->get_noise_generators().size(); c1++){
//		this->noise_generators[c1]->update_gaussian();
//	}
//}
//void Model::update_ode(){
//	for(int c1 = 0; c1 < this->masses.size(); c1++){
//		this->masses[c1]->update_ode();
//	}
//}
//
//void Model::update_state(double dt){
//	for(int c1 = 0; c1 < this->masses.size(); c1++){
//		this->masses[c1]->update_state(dt);
//	}
//}



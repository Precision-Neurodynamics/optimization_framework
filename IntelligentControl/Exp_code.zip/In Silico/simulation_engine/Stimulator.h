/*
 * Stimulator.h
 *
 *  Created on: Dec 3, 2015
 *      Author: mconnolly
 */

#ifndef STIMULATOR_H_
#define STIMULATOR_H_

namespace std {

class Stimulator {
public:
	Stimulator();
	virtual ~Stimulator();
};

} /* namespace std */

#endif /* STIMULATOR_H_ */

/*
 * Solver.cpp
 *
 *  Created on: Aug 30, 2015
 *      Author: mconnolly
 */

#include "Solver.h"

Solver::Solver() {
	// TODO Auto-generated constructor stub

}

Solver::~Solver() {
	// TODO Auto-generated destructor stub
}

